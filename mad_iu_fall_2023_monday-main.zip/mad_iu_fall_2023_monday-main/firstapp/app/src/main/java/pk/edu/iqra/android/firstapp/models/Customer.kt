package pk.edu.iqra.android.firstapp.models

class Customer(var name:String) {
    companion object {
        val OS = 32

        fun myFun() = "Hello world!"
        fun myFun1() :String{

            return "Hello world!"
        }
    }
}