package pk.edu.iqra.android.firstapp.utils

import android.widget.EditText
fun EditText.getUIText() = this.text.toString().trim()